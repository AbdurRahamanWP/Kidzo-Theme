<?php
add_filter( 'get_search_form', function($form) {
    $value = get_search_query() ? get_search_query() : '';
    $form = '<div class="widget single_sidebar form_item">
                <form action="'.esc_url(home_url("/")).'" class="search_form">
                    <input type="search" name="s" placeholder="'.esc_attr__( 'Search...', 'kidzo' ).'" value="'.esc_attr($value).'">
                    <i class="icon_search"></i>
                </form>
             </div>';
    return $form;
});