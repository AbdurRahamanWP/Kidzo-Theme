<div class="single_page_blog_post audio_post">
    
    
    <div class="post_thumb">
        <div class="audio_post_content">
            <audio preload="auto" controls>
                <source src="https://www.w3schools.com/html/horse.mp3">
            </audio>
        </div>
    </div>
    <div class="single_blog_content">
        <h2> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </h2>
        <p><?php echo  wp_trim_words( get_the_content(), 35, false ); ?></p>
        <div class="blog_btn">
        <a href="<?php the_permalink(); ?>" class="read_more_btn"><?php echo esc_html__( 'Read More', 'kidzo' ); ?>  <i class="flaticon-right-arrow"></i> </a>
            <p><i class="far fa-comment"></i><?php kidzo_comment_count( get_the_ID() ); ?></p>
        </div>
    </div>
</div>
