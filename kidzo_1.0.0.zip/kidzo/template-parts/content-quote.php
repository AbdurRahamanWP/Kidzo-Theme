<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package kidzo
 */

?>
<div <?php post_class('blog_single_item bg_gray code_post wow fadeInUp'); ?>>
    <div class="blog_post">
        <div class="post_content">
	        <?php kidzo_get_html_tag('blockquote', get_the_content()); ?>
        </div>
    </div>
</div>