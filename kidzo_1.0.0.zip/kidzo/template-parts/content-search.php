<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Kidzo
 */

?>
<div class="single_page_blog_post">
	<?php  if( has_post_thumbnail() ){ ?>
        <?php the_post_thumbnail('kidzo_740x400', array('class' => 'img-fluid')) ?>
	<?php } ?>
    <div class="single_blog_content">
        <h2> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> </h2>
        <p><?php echo  wp_trim_words( get_the_content(), 46, false ); ?></p>
        <div class="blog_btn">
        <a href="<?php the_permalink(); ?>" class="read_more_btn"><?php echo esc_html__( 'Read More', 'kidzo' ); ?>  <i class="flaticon-right-arrow"></i> </a>
            <p><i class="far fa-comment"></i><?php kidzo_comment_count( get_the_ID() ); ?></p>
        </div>
    </div>
</div>

