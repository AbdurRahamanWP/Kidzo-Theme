<?php
// Register Widget areas
add_action('widgets_init', function() {


    // Blog Sidebar
    register_sidebar( array(
        'name'          => esc_html__('Primary Sidebar', 'kidzo'),
        'description'   => esc_html__('Place widgets in sidebar widgets area.', 'kidzo'),
        'id'            => 'sidebar_widgets',
        'before_widget' => '<div id="%1$s" class="widget single_sidebar %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>'
    ));


    // Footer Widgets
    register_sidebar(array(
        'name'          => esc_html__('Footer widgets', 'kidzo'),
        'description'   => esc_html__('Add widgets here for Footer widgets area', 'kidzo'),
        'id'            => 'footer_widgets',
        'before_widget' => '<div id="%1$s" class="footer-widget col-lg-3 col-sm-6 wow fadeInDown %2$s" data-wow-delay=".3s">
                            <div class="single_footer_widget">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<h4>',
        'after_title'   => '</h4>'
    ));


});
