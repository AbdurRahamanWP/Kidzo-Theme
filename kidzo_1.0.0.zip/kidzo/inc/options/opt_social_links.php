<?php
Redux::setSection('kidzo_opt', array(
    'title'     => esc_html__('Social links', 'kidzo'),
    'id'        => 'opt_social_links',
    'icon'      => 'dashicons dashicons-share',
    'fields'    => array(
        array(
            'id'    => 'facebook',
            'type'  => 'text',
            'title' => esc_html__('Facebook', 'kidzo'),
            'default'	 => ''
        ),
        array(
            'id'    => 'twitter',
            'type'  => 'text',
            'title' => esc_html__('Twitter', 'kidzo'),
            'default'	  => ''
        ),
        array(
            'id'    => 'vimeo',
            'type'  => 'text',
            'title' => esc_html__('Vimeo', 'kidzo'),
            'default'	  => ''
        ),
        array(
            'id'    => 'linkedin',
            'type'  => 'text',
            'title' => esc_html__('LinkedIn', 'kidzo'),
            'default'	  => ''
        ),
        array(
            'id'    => 'dribbble',
            'type'  => 'text',
            'title' => esc_html__('Dribbble', 'kidzo'),
            'default'	  => ''
        ),
        array(
            'id'    => 'youtube',
            'type'  => 'text',
            'title' => esc_html__('Youtube', 'kidzo'),
        ),
        array(
            'id'    => 'instagram',
            'type'  => 'text',
            'title' => esc_html__('Instagram', 'kidzo'),
        ),
    ),
));