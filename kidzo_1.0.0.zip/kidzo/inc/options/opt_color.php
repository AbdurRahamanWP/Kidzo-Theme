<?php

// Color option
Redux::setSection('kidzo_opt', array(
	'title'     => esc_html__('Color Settings', 'kidzo'),
	'id'        => 'color',
	'icon'      => 'dashicons dashicons-admin-appearance',
	'fields'    => array(
        array(
            'id'          => 'accent_solid_color',
            'type'        => 'color',
            'title'       => esc_html__( 'Accent Color', 'kidzo' ),
            'output'      => array(
                'color' => '
                    a:hover,
                    a.link,
                    a.link:hover,
                    .cu_btn.btn_1,
                    .banner_part .single_banner_part .banner_iner .cu_btn:hover,
                    .cu_btn.btn_2:hover,
                    .single_success_story h4 a:hover,
                    .home_two_banner .single_banner_part .banner_iner h5,
                    .single_program_list .single_program_list_content h4 a:hover,
                    .single_program_list .single_program_list_content .program_list_details h5 span,
                    .section_tittle h5 span,
                    .about_section .about_section_content .list_content ul li i,
                    .single_team_section h4 a:hover,
                    .home_two_footer .single_footer_widget ul li a:hover,
                    .elementor a:hover,
                    .breadcrumb_part .breadcrumb_iner_link a:hover,
                    .s4_about_section .about_section_content h5,
                    .get_start_part .get_start_content .get_start_btn,
                    .single_page_blog_post .single_blog_content h2 a:hover,
                    .single_page_blog_post .blog_btn .read_more_btn:hover,
                    .blog_sidebar .single_sidebar .single_sidebar_post .sidebar_post_content h4 a:hover,
                    li.cat-item a:hover,
                    .blog_page_single_item .reply_btn:hover,
                    .menu_fixed .cu_btn,
                    .event_section .event_section_content h5,
                    .event_list .single_event_list .event_list_content h5,
                    .event_list .single_event_list .event_list_content ul li span,
                    .event_list .single_event_list .event_list_content ul li i,
                    .program_list_page .filters ul li.is-checked,
                    .program_list_page .filters ul li:hover,
                    .header_style_3 .dropdown-item:hover
                    ',
                'background-color' => '
                    .header_part .sub_header,
                    .cu_btn.btn_2,
                    .cu_btn.btn_1:hover,
                    .home_two_feture,
                    .get_start_part .get_start_content .get_start_btn:after,
                    .single_page_blog_post .post_author span,
                    .page_pageination a:hover,
                    .page_pageination .current,
                    a.tag-cloud-link:hover,
                    .cu_btn.white_btn:hover,
                    input.wpcf7-form-control.wpcf7-submit.cu_btn.btn_2,
                    .teacher_details_info .profile_content h4 span,
                    .cta_part
                    ',
                'border-color' => '
                    .cu_btn.btn_1,
                    .cu_btn.btn_1:hover,
                    .cu_btn.btn_2,
                    .cu_btn.btn_2:hover,
                    .page_pageination a:hover,
                    .page_pageination .current,
                    a.tag-cloud-link:hover,
                    .cu_btn.white_btn:hover,
                    .menu_fixed .cu_btn,
                    input.wpcf7-form-control.wpcf7-submit.cu_btn.btn_2
                    ',
            ),
        ),

        array(
            'id'          => 'anchor_tag_color',
            'type'        => 'link_color',
            'title'       => esc_html__( 'Link Color', 'kidzo' ),
            'output'      => 'a'
        )

	)
));

