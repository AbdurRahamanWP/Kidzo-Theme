<?php
/**
 * Custom Post Types
 */
Redux::setSection( 'kidzo_opt', array(
    'title'     => esc_html__( 'Custom Post Types', 'kidzo' ),
    'id'        => 'cpt_opt',
    'icon'      => 'dashicons dashicons-admin-post',
));

/**
 * Post Types
 */
Redux::setSection( 'kidzo_opt', array(
    'title'     => esc_html__( 'Post Types', 'kidzo' ),
    'id'        => 'cpt',
    'icon'      => 'el el-lines',
    'subsection'=> true,
    'fields'    => array(
        array(
            'id'        => 'cpt_note',
            'type'      => 'info',
            'style'     => 'success',
            'title'     => esc_html__( 'Enable Disable Custom Post Types', 'kidzo' ),
            'icon'      => 'dashicons dashicons-info',
            'desc'      => esc_html__( 'If you want, you can disable any custom post type of kidzo from here.', 'kidzo' )
        ),
        array(
            'id'       => 'is_teachers_cpt',
            'type'     => 'switch',
            'title'    => esc_html__('Teachers Post Type', 'kidzo' ),
            'on'       => esc_html__( 'Enable', 'kidzo' ),
            'off'      => esc_html__( 'Disable', 'kidzo' ),
            'default'  => true,
        ),
        array(
            'id'       => 'is_footer_cpt',
            'type'     => 'switch',
            'title'    => esc_html__( 'Footer Post Type', 'kidzo' ),
            'on'       => esc_html__( 'Enable', 'kidzo' ),
            'off'      => esc_html__( 'Disable', 'kidzo' ),
            'default'  => true,
        ),
    )
));

/**
 * Slug Re-write
 */
Redux::setSection( 'kidzo_opt', array(
    'title'     => esc_html__( 'Post Type Slugs', 'kidzo' ),
    'id'        => 'kidzo_cp_slugs',
    'icon'      => 'el el-lines',
    'subsection'=> true,
    'fields'    => array(
        array(
            'id'        => 'cp_slug_note',
            'type'      => 'info',
            'style'     => 'warning',
            'title'     => esc_html__( 'Slug Re-write:', 'kidzo' ),
            'icon'      => 'dashicons dashicons-info',
            'desc'      => sprintf (
                '%1$s <a href="%2$s"> %3$s</a> %4$s',
                esc_html__( "These are the custom post's slugs offered by kidzo. You can customize the permalink structure (site_domain/post_type_slug/post_lug) by changing the slug from here. Don't forget to save the permalinks settings from", 'kidzo' ),
                get_admin_url( null, 'options-permalink.php' ),
                esc_html__( 'Settings > Permalinks', 'kidzo' ),
                esc_html__( 'after changing the slug value.', 'kidzo' )
            )
        ),
        array(
            'title'     => esc_html__( 'Teachers Slug', 'kidzo' ),
            'id'        => 'teachers_slug',
            'type'      => 'text',
            'default'   => 'teachers'
        ),

    )
));

/**
 * Post Types
 */
Redux::setSection( 'kidzo_opt', array(
    'title'     => esc_html__( 'Event Single', 'kidzo' ),
    'id'        => 'event_single',
    'icon'      => 'el el-lines',
    'subsection'=> true,
    'fields'    => array(
        array(
            'id'       => 'is_animation_show',
            'type'     => 'switch',
            'title'    => esc_html__('Animation Images', 'kidzo' ),
            'on'       => esc_html__( 'Show', 'kidzo' ),
            'off'      => esc_html__( 'Hidden', 'kidzo' ),
            'default'  => false,
        ),
        array(
            'title'     => esc_html__('Animation Images', 'kidzo'),
            'subtitle'  => esc_html__('Give here the Events Animation Images ', 'kidzo'),
            'id'        => 'animation_images',
            'type'      => 'gallery',
            'required' => array( 'is_animation_show', '=', 1 )
        ),
        array(
            'id'       => 'is_related_item_show',
            'type'     => 'switch',
            'title'    => esc_html__( 'Related Event', 'kidzo' ),
            'on'       => esc_html__( 'Show', 'kidzo' ),
            'off'      => esc_html__( 'Hidden', 'kidzo' ),
            'default'  => true,
        ),
        array(
            'title'     => esc_html__('Related Event Title', 'kidzo'),
            'subtitle'  => esc_html__('Give here the Related Events Title ', 'kidzo'),
            'desc'      => esc_html__('This text will be show on Events Single Page', 'kidzo'),
            'id'        => 'related_title',
            'type'      => 'text',
            'default'   => esc_html__('Related Events', 'kidzo'),
            'required' => array( 'is_related_item_show', '=', 1 )
        ),
        array(
            'id'       => 'is_related_item_img_show',
            'type'     => 'switch',
            'title'    => esc_html__( 'Related Event Animation Images', 'kidzo' ),
            'on'       => esc_html__( 'Show', 'kidzo' ),
            'off'      => esc_html__( 'Hidden', 'kidzo' ),
            'default'  => false,
            'required' => array( 'is_related_item_show', '=', 1 )
        ),
        array(
            'title'     => esc_html__('Related Animation Images', 'kidzo'),
            'subtitle'  => esc_html__('Give here the Related Events Animation Images ', 'kidzo'),
            'id'        => 'related_animation_images',
            'type'      => 'gallery',
            'required' => array( 'is_related_item_img_show', '=', 1 )
        ),
    )
));