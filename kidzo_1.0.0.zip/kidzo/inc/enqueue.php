<?php

/**
 * Register Google fonts.
 *
 * @return string Google fonts URL for the theme.
 */
function kidzo_fonts_url() {
    $fonts_url = '';
    $fonts     = array();
    $subsets   = '';

    /* Body font */
    if ( 'off' !== 'on' ) {
        $fonts[] = "Quicksand:200,300,400,500,600,700";
    }

    $is_ssl = is_ssl() ? 'https' : 'http';

    if ( $fonts ) {
        $fonts_url = add_query_arg( array(
            'family' => urlencode( implode( '|', $fonts ) ),
            'subset' => urlencode( $subsets ),
        ), "$is_ssl://fonts.googleapis.com/css" );
    }

    return $fonts_url;
}
function kidzo_enque_scripts() {
    wp_deregister_style( 'elementor-animations' );
    wp_enqueue_style('kidzo-fonts', kidzo_fonts_url(), array(), null);
    wp_enqueue_style('animate',  KIDZO_DIR_CSS.'/animate.css');
    wp_enqueue_style('bootstrap',  KIDZO_DIR_CSS.'/bootstrap.min.css');
    wp_enqueue_style('flaticon',  KIDZO_DIR_CSS.'/flaticon.css');
    wp_enqueue_style('kidzo-main-style',  KIDZO_DIR_CSS.'/style.css');
    wp_enqueue_style('wpd-style',  KIDZO_DIR_CSS.'/wpd-style.css');
    wp_enqueue_style('kidzo-gutenberg',  KIDZO_DIR_CSS.'/kidzo-gutenberg.css');
    // js Style
    wp_enqueue_script( 'bootstrap-min', KIDZO_DIR_JS.'/bootstrap.min.js', array('jquery'), '4.4.1', true );
    // Vandor Style
    wp_enqueue_style('themefy_icon',  KIDZO_DIR_VEND.'/themefy_icon/themify-icons.css');
    wp_enqueue_style('owl_carousel',  KIDZO_DIR_VEND.'/owl_carousel/css/owl.carousel.css');
    wp_enqueue_style('nice-select_style',  KIDZO_DIR_VEND.'/niceselect/css/nice-select.css');
    wp_enqueue_style('magnific-popup',  KIDZO_DIR_VEND.'/magnify_popup/magnific-popup.css');
    wp_enqueue_style('fontawesome',  KIDZO_DIR_VEND.'/fontawesome/css/all.css');
    wp_enqueue_style('elegent_icon',  KIDZO_DIR_VEND.'/elegant_Icon/elegent_icon.css');
    wp_enqueue_style( 'kidzo-root-style', get_stylesheet_uri() );




    wp_enqueue_script( 'popper', KIDZO_DIR_JS.'/popper.min.js', array('jquery'), '1.1.0', true );
    // Vandor js Style 
    wp_enqueue_script( 'wow', KIDZO_DIR_VEND.'/wow/wow.min.js', array('jquery'), '1.1.3', true );
    wp_enqueue_script( 'progressbar', KIDZO_DIR_VEND.'/progressbar/jquery.barfiller.js', array('jquery'), '1.0.1', true );
    wp_enqueue_script( 'parallax', KIDZO_DIR_VEND.'/parallax/parallax.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'parallax-scroll', KIDZO_DIR_VEND.'/parallax/jquery.parallax-scroll.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'owl_carousel', KIDZO_DIR_VEND.'/owl_carousel/js/owl.carousel.min.js', array('jquery'), '2.3.4', true );
    wp_enqueue_script( 'nice-select', KIDZO_DIR_VEND.'/niceselect/js/jquery.nice-select.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'magnify_popup', KIDZO_DIR_VEND.'/magnify_popup/jquery.magnific-popup.js', array('jquery'), '1.1.0', true );
    wp_enqueue_script( 'isotope.pkgd', KIDZO_DIR_VEND.'/isotop/isotope.pkgd.js', array('jquery'), '3.0.6', true );
    wp_enqueue_script( 'gmap3', KIDZO_DIR_VEND.'/gmp3/gmap3.min.js', array('jquery'), '7.2', true );
    wp_enqueue_script( 'map', KIDZO_DIR_VEND.'/gmp3/map.js', array('jquery'), '3.0.6', true );
    wp_enqueue_script( 'jquery.counterup', KIDZO_DIR_VEND.'/counter/jquery.counterup.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'jquery.countTo', KIDZO_DIR_VEND.'/counter/jquery.countTo.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'jquery.waypoints', KIDZO_DIR_VEND.'/counter/jquery.waypoints.min.js', array('jquery'), '4.0.0', true );
   
    wp_enqueue_script( 'kidzo-custom', KIDZO_DIR_JS.'/custom.js', array('jquery'), '1.0.0', true ); 
    
    
  // Custome Header Option
  $dynamic_css_style = '';
    if(get_option('kidzo_opt')) {
        $opt = get_option('kidzo_opt');
        $header_background_bg  = isset( $opt['header_background_bg']['url'] ) ? $opt['header_background_bg']['url'] : '';
        if ( $header_background_bg ) {
            $dynamic_css_style .= "
            .breadcrumb_part.parallax_bg{
                background-image:url( $header_background_bg ) !important;
            }";
        }
    }

   wp_add_inline_style('kidzo-root-style', $dynamic_css_style);

   // Header bg End

}

add_action( 'wp_enqueue_scripts', 'kidzo_enque_scripts' );