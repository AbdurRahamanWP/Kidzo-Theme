<?php
/**
 *  Template Name: Teacher Information
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package kidzo
 */
get_header();
$prev_post = get_previous_post();
$next_post = get_next_post();
?>
<section class="teacher_details_info section_padding">
  <?php 
    while (have_posts()) : the_post();
        $cats = get_the_terms(get_the_ID(), 'teachers_cat');
        $cat_slug = '';
        $cat_name = '';
        if(is_array($cats)) {
            foreach ($cats as $cat) {
                $cat_slug .= $cat->slug.' ';
                $cat_name .= $cat->name.' ';
            }
        }
        $teachers_designation = function_exists( 'get_field' ) ? get_field( 'teachers_designation' ) : '';
        $email_id             = function_exists( 'get_field' ) ? get_field( 'email_id' ) : '';
        $phone_number         = function_exists( 'get_field' ) ? get_field( 'phone_number' ) : '';
        $short_description    = function_exists( 'get_field' ) ? get_field( 'short_description' ) : '';
        ?>
            <div class="container custom_container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-sm-5 wow fadeInUp" data-wow-delay=".3s">
                        <div class="profile_img">
                            <?php  if( has_post_thumbnail() ){ ?>
                            <?php the_post_thumbnail('kidzo_740x400', array('class' => 'img-fluid')) ?>
                            <?php } ?>

                        </div>
                    </div>
                    <div class="col-lg-8 col-sm-7 wow fadeInUp" data-wow-delay=".5s">
                        <div class="profile_content">
                            <h4><?php the_title(); ?> <span><?php echo wp_kses_post( $cat_name ); ?></span></h4>
                            <ul>
                                <li><i class="fas fa-envelope"></i> <?php echo wp_kses_post( $email_id ); ?></li>
                                <li><i class="fas fa-phone-alt"></i> <?php echo wp_kses_post( $phone_number ); ?></li>
                            </ul>
                            <p><?php echo wp_kses_post($short_description); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        the_content();
    endwhile; 
    ?>
</section>
<?php
get_footer();