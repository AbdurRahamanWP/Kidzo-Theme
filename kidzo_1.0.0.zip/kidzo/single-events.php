<?php
/**
 *  Template Name: events Information
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package kidzo
 */
get_header();
$opt = get_option('kidzo_opt');
$is_animation     = isset( $opt['is_animation_show']) ? $opt['is_animation_show'] : '';
$is_related_item  = isset( $opt['is_related_item_show']) ? $opt['is_related_item_show'] : '';
$related_title    = isset( $opt['related_title']) ? $opt['related_title'] : '';
$related_item_img = isset( $opt['is_related_item_img_show']) ? $opt['is_related_item_img_show'] : '';
$animation_images = isset( $opt['animation_images']) ? $opt['animation_images'] : '';
$related_animation= isset( $opt['related_animation_images']) ? $opt['related_animation_images'] : '';

?>
<!-- event section part here -->
<section class="event_section section_padding event_details">
    <?php 
    while (have_posts()) : the_post();
    $cats = get_the_terms(get_the_ID(), 'events_cat');
    $cat_slug = '';
     $cat_name = '';
    if(is_array($cats)) {
        foreach ($cats as $cat) {
            $cat_slug .= $cat->slug.' ';
            $cat_name .= $cat->name.' ';
        }
    }
    $event_date     = strtotime(get_field('event_date'));
    $event_time     = function_exists( 'get_field' ) ? get_field( 'event_time' ) : '';
    $event_location = function_exists( 'get_field' ) ? get_field( 'event_location' ) : '';
    $contact_number = function_exists( 'get_field' ) ? get_field( 'contact_number' ) : '';
    ?>
    <div class="container custom_container">
        <div class="row justify-content-between align-items-center">
            <div class="col-sm-6 col-sm-6">
                <div class="img_section">
                    <?php  if( has_post_thumbnail() ){ ?>
                     <?php the_post_thumbnail('kidzo_740x400', array('class' => 'about_img_6 img-fluid')) ?>
                    <?php } ?>
                </div>
            </div>
            <div class="col-sm-6 col-sm-6">
                <div class="event_section_content">
                    <h2 class="wow fadeInDown" data-wow-delay=".4s"><?php the_title(); ?></h2>
                    <?php the_content(); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="single_event_section_part">
                    <div class="row justify-content-between">
                        <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay=".2s">
                            <div class="single_event_part">
                                <div class="single_event_icon">
                                <img src="<?php echo esc_url(get_template_directory_uri()) ?>/assets/img/calender.png" alt="<?php esc_attr_e( 'Location', 'kidzo' ) ?>" class="img-fluid">   
                                </div>
                                <h4><?php esc_html_e('event Date & Time','kidzo'); ?></h4>
                                <p><?php echo date(get_option('date_format'), $event_date); ?>  <?php echo wp_kses_post($event_time); ?></p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay=".5s">
                            <div class="single_event_part single_orange_bg">
                                <div class="single_event_icon">
                                   <img src="<?php echo esc_url(get_template_directory_uri()) ?>/assets/img/location.png" alt="<?php esc_attr_e( 'Location', 'kidzo' ) ?>" class="img-fluid">
                                </div>
                                <h4><?php esc_html_e('event location','kidzo'); ?></h4>
                                <p><?php echo wp_kses_post($event_location); ?></p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay=".8s">
                            <div class="single_event_part blue_bg">
                                <div class="single_event_icon">
                                    <img src="<?php echo esc_url(get_template_directory_uri()) ?>/assets/img/call.png" alt="<?php esc_attr_e( 'Location', 'kidzo' ) ?>" class="img-fluid">
                                </div>
                                <h4><?php esc_html_e('Contact Us','kidzo'); ?></h4>
                                <p><?php echo wp_kses_post($contact_number); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    endwhile; 
    if($is_animation == 1): 
        $animation = explode(",", $related_animation);
        $i = 1;
        foreach($animation as $images):
            $imag_ani = wp_get_attachment_image_src($images);
                if($i == 1){ ?>
                    <div class="about_page_animation_1">
                        <div data-parallax='{"x": 2, "y": 70, "rotateZ":0}'>
                            <?php echo wp_get_attachment_image($images, 'full') ?>
                        </div>
                    </div>
                <?php }elseif ($i == 2) { ?>
                    <div class="about_page_animation_2">
                        <div data-parallax='{"x": 10, "y": 80, "rotateZ":0}'>
                            <?php echo wp_get_attachment_image($images, 'full') ?>
                        </div>
                    </div>
                <?php  } elseif ($i == 3) { ?>
                    <div class="about_page_animation_3">
                        <div data-parallax='{"x": 30, "y": 60, "rotateZ":0}'>
                            <?php echo wp_get_attachment_image($images, 'full') ?>
                        </div>
                    </div>
                <?php  } elseif ($i == 4) { ?>
                    <div class="about_page_animation_4">
                        <div data-parallax='{"x": 30, "y": -50, "rotateZ":0}'>
                            <?php echo wp_get_attachment_image($images, 'full') ?>
                        </div>
                    </div>
                <?php }
            $i++;
        endforeach; 
    endif;
    ?>
</section>
<!-- event section part end -->
<?php if($is_related_item == 1): ?>
 <!-- event list part here -->
<section class="event_list section_padding section_bg_1">
    <div class="container custom_container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="section_tittle">
                    <h2 class="wow fadeInDown" data-wow-delay=".5s"> <?php echo wp_kses_post($related_title); ?> </h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <?php
             $args = array(
                'post_type' => 'events',
                'post_status' => 'publish',
                'posts_per_page' => 4, 
                'order' => 'DESC', 
            );

            $evemt_list = new WP_Query( $args ); 
            if( $evemt_list->have_posts() ){
                while ( $evemt_list->have_posts() ){
                    $evemt_list->the_post();
                    $event_date     = function_exists( 'get_field' ) ? strtotime(get_field( 'event_date' )) : '';
                    $event_time     = function_exists( 'get_field' ) ? get_field( 'event_time' ) : '';
                    $event_location = function_exists( 'get_field' ) ? get_field( 'event_location' ) : '';
                    $address = substr($event_location, 0, 7);

                    if( has_post_thumbnail() ) {
                        $cats = get_the_terms(get_the_ID(), 'events_cat');
                        $cat_slug = '';
                        $cat_name = '';
                        if(is_array($cats)) {
                            foreach ($cats as $cat) {
                                $cat_slug .= $cat->slug.' ';
                                $cat_name .= $cat->name.' ';
                            }
                        }
                        ?>
                        <div class="col-lg-6 col-md-12 wow fadeInUp" data-wow-delay=".2s">
                            <div class="single_event_list">
                                <div class="event_list_img">
                                    <?php 
                                        if ( has_post_thumbnail() ) { ?>
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail('medium', array('class' => 'img-fluid')); ?>
                                        </a>
                                        <?php 
                                        } 
                                    ?>
                                </div>
                                <div class="event_list_content">
                                    <h5><?php echo date('d', $event_date); ?> <?php echo date('M', $event_date); ?></h5>
                                    <h3> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                    <p><?php echo  wp_trim_words( get_the_content(), 10, false ); ?></p>
                                    <ul>
                                        <li><i class="fas fa-clock"></i><?php esc_html_e('Time: ','kidzo'); ?><span><?php echo wp_kses_post($event_time); ?></span></li>
                                        <li><i class="fas fa-map-marker-alt"></i><?php esc_html_e('Location: ','kidzo'); ?><span><?php echo wp_kses_post($address); ?></span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                }
            }
            ?>
        </div>
    </div>
    <?php if($related_item_img == 1):
            $logos = explode(",", $related_animation);
            $i = 1;
            foreach($logos as $image):
                $imag_var = wp_get_attachment_image_src($image);
                ?>
                    <?php if($i == 1){ ?>
                        <div class="event_list_animation_1">
                            <div data-parallax='{"x": 2, "y": 70, "rotateZ":0}'>
                                <?php echo wp_get_attachment_image($image, 'full') ?>
                            </div>
                        </div>
                    <?php }elseif ($i == 2) { ?>
                        <div class="event_list_animation_3">
                            <div data-parallax='{"x": 30, "y": 60, "rotateZ":0}'>
                                <?php echo wp_get_attachment_image($image, 'full') ?>
                            </div>
                        </div>
                    <?php  } elseif ($i == 3) { ?>
                        <div class="event_list_animation_4">
                            <div data-parallax='{"x": 30, "y": -50, "rotateZ":0}'>
                             <?php echo wp_get_attachment_image($image, 'full') ?>
                            </div>
                        </div>
                    <?php } ?>
                <?php
            $i++;
            endforeach; 
        endif; ?>
</section>
<!-- event list part end -->
<?php endif; ?>
<?php
get_footer();