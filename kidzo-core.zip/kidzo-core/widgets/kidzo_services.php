<?php
namespace kidzoCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Typography;



// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
/**
 * Text Typing Effect
 *
 * Elementor widget for text typing effect.
 *
 * @since 1.7.0
 */
class kidzo_services extends Widget_Base {

    public function get_name() {
        return 'kidzo_features';
    }

    public function get_title() {
        return __( 'Services', 'kidzo-core' );
    }

    public function get_icon() {
        return ' eicon-column';
    }

    public function get_categories() {
        return [ 'kidzo-elements' ];
    }

    protected function _register_controls() {

	    $services = new \Elementor\Repeater();
        // ------------------------------  Title  ------------------------------
        $this->start_controls_section(
            'title_sec', [
                'label' => __( 'Section Information', 'kidzo-core' ),
            ]
        );
        $this->add_control(
            'sectitle', [
                'label'       => esc_html__( 'Title Text', 'kidzo-core' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => false,
                'default'     => 'Service'
            ]
        );
        $this->add_control(
            'title_html_tag',
            [
                'label' => __( 'Title HTML Tag', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                ],
                'default' => 'h5',
            ]
            );

        $this->add_control(
            'color_title', [
                'label' => __( 'Text Color', 'kidzo-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section_tittle h5' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'typography_title',
                'selector' => '
                    {{WRAPPER}} .section_tittle h5'
            ]
        );

         $this->add_control(
            'sec_sub_title', [
                'label'       => esc_html__( 'Sub Title Text', 'kidzo-core' ),
                'description' => esc_html__( 'Use <br> tag for line breaking.', 'kidzo-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default'     => 'Welcome to Droit Child Care',
                 'separator' => 'before',
            ]
        );
        $this->add_control(
            'wave_shap_img',
            [
                'label' => esc_html__( 'Wave Line Shap', 'kidzo-core' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'color__sub_title', [
                'label' => __( 'Sub Text Color', 'kidzo-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section_tittle h2' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(), [
                'name' => 'typography_sub_title',
                'selector' => '
                    {{WRAPPER}} .section_tittle h2,
                '
            ]
        );
        $this->end_controls_section(); // End Sub title section

        /*======================= Feature Settings  ======================== */
        $kidzo_services = new \Elementor\Repeater();
        $this->start_controls_section(
            'kidzo_features_sec', [
                'label' => __( 'Kidzo Service', 'kidzo-core' ),
            ]
        );
        
        $kidzo_services->add_control(
            'tf_title', [
                'label' => __( 'Service title', 'kidzo-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'default' => 'Pre-School Sports'
            ]
        );
        $kidzo_services->add_control(
            'tf_feature_img', [
                'label' => __( 'Feature Image', 'kidzo-core' ),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $this->add_control(
            'tf_features', [
                'label' => __( 'Features', 'kidzo-core' ),
                'type' => Controls_Manager::REPEATER,
                'title_field' => '{{{ tf_title }}}',
                'fields' => $kidzo_services->get_controls(),
            ]
        );
        $this->end_controls_section();
        /*================= End Feature  =============*/

        /*===================== Button =========================*/
        $this->start_controls_section(
            'section_button',
            [
                'label' => __( 'Button', 'kidzo-core' ),
            ]
        );
        $this->add_control(
            'button_label',
            [
                'label' => esc_html__( 'Button Label', 'kidzo-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Get Started',
            ]
        );
        $this->add_control(
            'button_url',
            [
                'label' => esc_html__( 'Button Url', 'kidzo-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '#',
            ]
        );

        $this->start_controls_tabs(
			'style_tabs'
		);

		//button Style Normal Style
		$this->start_controls_tab(
			'style_normal',
			[
				'label' => __( 'Normal', 'kidzo-core' ),
			]
		);

		$this->add_control(
			'btn_font_color', [
				'label' => esc_html__( 'Font color', 'kidzo-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cu_btn.btn_2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_bg_color', [
				'label' => esc_html__( 'Background Color', 'kidzo-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cu_btn.btn_2' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cta_btn_border_color', [
				'label' => __( 'Border Color', 'kidzo-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cu_btn.btn_2' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		//Hover Color
		$this->start_controls_tab(
			'style_hover_btn',
			[
				'label' => __( 'Hover', 'kidzo-core' ),
			]
		);   

		$this->add_control(
			'hover_font_color', [
				'label' => __( 'Font Color', 'kidzo-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cu_btn.btn_2:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_bg_color', [
				'label' => __( 'Background Color', 'kidzo-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cu_btn.btn_2:hover' => 'background: {{VALUE}};',
				]

			]
		);

		$this->add_control(
			'hover_border_color', [
				'label' => __( 'Border Color', 'kidzo-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cu_btn.btn_2:hover' => 'border-color: {{VALUE}};',
				]

			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
        $this->end_controls_section();

        /*===================== Feature Images =========================*/
        $this->start_controls_section(
            'service_feature_img',
            [
                'label' => __( 'Feature Image', 'kidzo-core' ),
            ]
        );
        $this->add_control(
            'feature_img',
            [
                'label' => esc_html__( 'Feature Image (Top Right)', 'kidzo-core' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        $this->add_control(
            'feature_img_2',
            [
                'label' => esc_html__( 'Feature Image (Buttom Left)', 'kidzo-core' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,

            ]
        );
        $this->end_controls_section();
    
    }
    protected function render() {
    $settings = $this->get_settings();
    $stitle     = !empty( $settings['sectitle'] ) ? $settings['sectitle'] : '';
    $sub_title  = !empty( $settings['sec_sub_title'] ) ? $settings['sec_sub_title'] : '';
    $title_tag  = !empty($settings['title_html_tag']) ? $settings['title_html_tag'] : 'h5';
    $tf_features   = !empty( $settings['tf_features'] ) ? $settings['tf_features'] : '';
    $wave_shap_img = !empty( $settings['wave_shap_img']['url'] ) ? $settings['wave_shap_img']['url'] : '';
    ?>
    <section class="services_part section_padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="section_tittle">
                        <?php
                            if(!empty($stitle)):
                                echo '<' . $title_tag . ' class="wow fadeInDown" data-wow-delay=".5s">' . wp_kses_post( nl2br( $stitle ) ) . '</' . $title_tag . '>';
                            endif;
                            if(!empty($sub_title)):
                        ?>
                        <h2 class="wow fadeInDown" data-wow-delay=".3s"><?php echo wp_kses_post($sub_title); ?></h2>
                        <?php endif; ?>
                            <div class="wave_line wow fadeInDown" data-wow-delay=".5s" <?php if( !empty($wave_shap_img) ): ?> style="background-image: url('<?php echo esc_url( $settings['wave_shap_img']['url'] ); ?>')" <?php endif; ?>></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php
                    if ( count( $tf_features ) > 0 ) {
                        $i=1;
                        foreach ( $tf_features as $feature ) { ?>
                            <div class="col-sm-6 col-lg-6 wow fadeInDown" data-wow-delay=".2s">
                                <div class="single_service_part">
                                    <?php if(!empty($feature['tf_feature_img']['url'])): ?>
                                        <img src="<?php echo esc_url( $feature['tf_feature_img']['url'] ); ?>" alt="<?php echo esc_attr( $feature['tf_feature_img'] ); ?>" class="img-fluid">
                                    <?php endif; ?>
                                    <?php if(!empty($feature['tf_title'])): ?>
                                      <h5 class="service_title"><?php echo wp_kses_post($feature['tf_title']); ?></h5>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php
                            $i++;
                        }
                    }
                 ?>
            </div>
            <?php if(!empty($settings['button_label'])): ?>
                <a href="<?php echo esc_url($settings['button_url']['url']); ?>" class="cu_btn btn_2 white_space wow fadeInDown" data-wow-delay=".3s"><?php echo wp_kses_post($settings['button_label']); ?></a>
            <?php endif; ?>
        </div>
        <?php if(!empty($settings['feature_img_2']['url'])): ?>
            <img src="<?php echo esc_url($settings['feature_img_2']['url']); ?>" alt="<?php echo esc_attr( $settings['feature_img_2'] ); ?>" class="pencel_img wow fadeInUp">
        <?php endif; ?>
        <?php if(!empty($settings['feature_img']['url'])): ?>
            <img src="<?php echo esc_url($settings['feature_img']['url']); ?>" alt="<?php echo esc_attr( $settings['feature_img'] ); ?>" class="galaxy_img wow fadeInDown">
        <?php endif; ?>
    </section>
    <?php
    }
}