;(function($){
    "use strict";

    $(document).ready(function () {

        /*--------- WOW js-----------*/
        function wowAnimation() {
            new WOW({
                offset: 100,
                mobile: true
            }).init();
        }
        wowAnimation();


        /*--------- Accordion js-----------*/
        function fAqactive(){
            $(".faq_accordian_two .card").on('click', function(){
                $(".faq_accordian_two .card").removeClass("active");
                $(this).addClass('active');
            });
        }
        fAqactive();

        $(document).ready(function() {
            $('.selectpickers').niceSelect();
        });

    }); // End Document.ready

})(jQuery);